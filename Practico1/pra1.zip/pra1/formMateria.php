<?php
require_once "config.php";

use App\dao\bll\MateriaBLL;

$id = 0;
$objMateria = null;
if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $objMateria = MateriaBLL::selectById($id);
}
//$listaCarreras = MateriaBLL::getAllCareers()
?>

<?php include_once "components/header.php" ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-4 mt-3 mb-3">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title">Formulario Materia</div>
                        <form method="post" action="indexMaterias.php">
                            <input type="hidden" value="<?php echo $id; ?>" name="id">
                            <input type="hidden" name="task" value="<?php echo $id == 0 ? "INSERT" : "UPDATE"; ?>">
                            <div>
                                <label>Nombre:</label>
                                <input name="nombre" type="text" class="form-control"
                                       value="<?php echo $objMateria != null ? $objMateria->getNombre() : ""; ?>">
                            </div>
                            <div>
                                <label>Semestre:</label>
                                <input name="semestre" type="number" class="form-control" min="1" max="8"
                                       value="<?php echo $objMateria != null ? $objMateria->getSemestre() : ""; ?>">
                            </div>
                            <div>
                                <label>Carrera:</label>
                                <input name="carrera" type="number" class="form-control""
                                value="<?php echo $objMateria != null ? $objMateria->getCarreraId() : ""; ?>">
                            </div>
                            <div class="mt-2">
                                <button class="btn btn-primary" type="submit">Guardar</button>
                                <a href="indexMaterias.php" class="btn btn-link">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include_once "components/footer.php" ?>