<?php

require_once "config.php";

use App\dao\bll\EstudianteBLL;

$usuario = $_GET['usuario'];
$contrasena = $_GET['contrasena'];

$estudiante = EstudianteBLL::validarEstudiante($usuario, $contrasena);

if ($estudiante) {
    header("location:indexInscripcion.php?id=".$estudiante->getId());
} else {
    header("location:index.php?msg=error");
}
