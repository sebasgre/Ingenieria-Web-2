<?php
require_once "config.php";

use App\dao\bll\CarreraBLL;
use App\dao\bll\MateriaBLL;

$task = "select";
if(isset($_REQUEST["task"])){
    $task = $_REQUEST["task"];
}

switch ($task){
    case "INSERT":
        $nombre = $_POST["nombre"];
        $semestre = $_POST["semestre"];
        $carrera = $_POST["carrera"];
        MateriaBLL::insert($nombre, $semestre, $carrera);
        break;
    case "UPDATE":
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $semestre = $_POST["semestre"];
        $carrera = $_POST["carrera"];
        MateriaBLL::update($nombre, $semestre, $carrera, $id);
        break;
    case "DELETE":
        $id = $_GET["id"];
        MateriaBLL::delete($id);
        break;
}
$listaMaterias = MateriaBLL::selectAll();
?>
<?php include_once "components/header.php" ?>
<div class="container-fluid">
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Lista de Materias</h5>

            <table class="table">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Semestre</th>
                    <th>Carrera</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($listaMaterias as $objMateria): ?>
                    <tr>
                        <?php
                            $carrera = CarreraBLL::selectById($objMateria->getCarreraId());
                        ?>
                        <td><?php echo $objMateria->getId();?></td>
                        <td><?php echo $objMateria->getNombre();?></td>
                        <td><?php echo $objMateria->getSemestre();?></td>
                        <td><?php echo $carrera->getNombres();?></td>
                        <td><a class="btn btn-primary"
                               href="formMateria.php?id=<?php echo $objMateria->getId(); ?>">Editar</a></td>
                        <td><a onclick="return confirm('Está seguro que desea eliminar la materia?')"
                               href="indexMaterias.php?id=<?php echo $objMateria->getId();?>&task=DELETE"
                               class="btn btn-danger">Eliminar</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include_once "components/footer.php" ?>


