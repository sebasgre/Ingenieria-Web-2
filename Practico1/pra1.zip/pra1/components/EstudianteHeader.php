<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script type="text/javascript" src="vendor/twbs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="vendor/twbs/bootstrap/dist/css/bootstrap.css">
    <!--<link rel="stylesheet" href="css/styles.css"/>-->
    <title>Document</title>
</head>

<body>
<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
    <div class="container-fluid">
        <?php

        use App\dao\bll\EstudianteBLL;

        $id = null;
        if (isset($_GET["id"])) {
            $id = $_GET["id"];
        }
        if (isset($_REQUEST["id"])) {
            $id = $_REQUEST["id"];
        }
//        $nombreCompleto = EstudianteBLL::selectById($id)->getNombres()." ".EstudianteBLL::selectById($id)->getApellidos();
        ?>
        <a class="navbar-brand" href="#">Practico 1</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        </div>
    </div>
</nav>