<?php
require_once "config.php";

use App\dao\bll\EstudianteBLL;
use App\dao\bll\InscripcionBLL;
use App\dao\bll\MateriaBLL;

$id = 0;
$objMaterias = null;
$objEstudiante = null;
$objInscripcion = null;
if (isset($_REQUEST["id"])) {
    $id = $_REQUEST["id"];
    $objEstudiante = EstudianteBLL::selectById($id);
    $objMaterias = MateriaBLL::selectBySemestreAndCarrera($objEstudiante->getSemestre(), $objEstudiante->getCarreraId(), $objEstudiante->getId());
}
?>

<?php include_once "components/EstudianteHeader.php" ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-4 mt-3 mb-3">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title">Formulario Mascota</div>
                        <form method="post" action="indexInscripcion.php">
                            <input type="hidden" value="<?php echo $id; ?>" name="id">
                            <input type="hidden" name="task" value="INSERT">
                            <div>
                                <label>Estudiante:</label>
                                <input name="nombre" type="text" class="form-control" disabled
                                       value="<?php echo $objEstudiante != null ? $objEstudiante->getNombres() . " " . $objEstudiante->getApellidos() : ""; ?>">
                            </div>
                            <div>
                                <label>Materia:</label>
                                <select name="idMateria" class="form-select">
                                    <?php foreach ($objMaterias as $objMateria): ?>
                                        <option value="<?php echo $objMateria->getId(); ?>">

                                            <?php echo $objMateria->getNombre(); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mt-2">
                                <button class="btn btn-primary" type="submit">Guardar</button>
                                <a href="indexInscripcion.php?id=<?php echo $id?>" class="btn btn-link">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include_once "components/footer.php" ?>