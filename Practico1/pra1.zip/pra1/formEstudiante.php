<?php
require_once "config.php";

use App\dao\bll\EstudianteBLL;
use App\dao\bll\PersonaBLL;

$id = 0;
$objEstudiante = null;
if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $objEstudiante = EstudianteBLL::selectById($id);
}
?>

<?php include_once "components/header.php" ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-4 mt-3 mb-3">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title">Formulario Estudiante</div>
                        <form method="post" action="indexEstudiantes.php">
                            <input type="hidden" value="<?php echo $id; ?>" name="id">
                            <input type="hidden" name="task" value="<?php echo $id == 0 ? "INSERT" : "UPDATE"; ?>">
                            <div>
                                <label>Nombre:</label>
                                <input name="nombre" type="text" class="form-control"
                                       value="<?php echo $objEstudiante != null ? $objEstudiante->getNombres() : ""; ?>">
                            </div>
                            <div>
                                <label>Apellidos:</label>
                                <input name="apellido" type="text" class="form-control"
                                       value="<?php echo $objEstudiante != null ? $objEstudiante->getApellidos() : ""; ?>">
                            </div>
                            <div>
                                <label>Usuario:</label>
                                <input name="usuario" type="text" class="form-control"
                                       value="<?php echo $objEstudiante != null ? $objEstudiante->getUsuario() : ""; ?>">
                            </div>
                            <div>
                                <label>Contraseña:</label>
                                <input name="contrasena" type="password" class="form-control" id="contrasena"
                                       value="<?php echo $objEstudiante != null ? $objEstudiante->getContrasena() : ""; ?>">
                                <input type="checkbox" onclick="myFunction()">Show Password
                            </div>
                            <div>
                                <label>Semestre:</label>
                                <input name="semestre" type="text" class="form-control"
                                       value="<?php echo $objEstudiante != null ? $objEstudiante->getSemestre() : ""; ?>">
                            </div>
                            <div>
                                <label>Carrera:</label>
                                <input name="carrera" type="text" class="form-control"
                                       value="<?php echo $objEstudiante != null ? $objEstudiante->getCarreraId() : ""; ?>">
                            </div>
                            <div class="mt-2">
                                <button class="btn btn-primary" type="submit">Guardar</button>
                                <a href="indexEstudiantes.php" class="btn btn-link">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include_once "components/footer.php" ?>

<script>
    function myFunction() {
        var x = document.getElementById("contrasena");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>
