<?php
require_once "config.php";

use App\dao\bll\CarreraBLL;

$id = 0;
$objCarrera = null;
if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $objCarrera = CarreraBLL::selectById($id);
}
?>

<?php include_once "components/header.php" ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-4 mt-3 mb-3">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title">Formulario Carrera</div>
                        <form method="post" action="indexCarreras.php">
                            <input type="hidden" value="<?php echo $id; ?>" name="id">
                            <input type="hidden" name="task" value="<?php echo $id == 0 ? "INSERT" : "UPDATE"; ?>">
                            <div>
                                <label>Nombre:</label>
                                <input name="nombre" type="text" class="form-control"
                                       value="<?php echo $objCarrera != null ? $objCarrera->getNombres() : ""; ?>">
                            </div>
                            <div class="mt-2">
                                <button class="btn btn-primary" type="submit">Guardar</button>
                                <a href="indexCarreras.php" class="btn btn-link">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include_once "components/footer.php" ?>