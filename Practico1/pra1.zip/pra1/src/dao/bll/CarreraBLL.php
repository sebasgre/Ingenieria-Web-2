<?php

namespace App\dao\bll;

use App\dao\dal\Connection;
use App\dao\dto\Carrera;
use PDO;

class CarreraBLL
{
    public static function insert($nombres): int
    {
        $conn = new Connection();
        $sql = "INSERT INTO carrera (nombres) VALUES(:varNombres)";
        $conn->queryWithParams($sql, array(
            ":varNombres" => $nombres
        ));
        return $conn->getLastInsertedId();
    }

    public static function update($nombres, $id)
    {
        $conn = new Connection();
        $sql = "UPDATE carrera SET nombres = :varNombres WHERE id = :varId";
        $conn->queryWithParams($sql, array(
            ":varNombres" => $nombres,
            ":varId" => $id
        ));
    }

    public static function delete($id)
    {
        $conn = new Connection();
        $sql = "DELETE FROM carrera WHERE id = :varId";
        $conn->queryWithParams($sql, array(
            ":varId" => $id
        ));
    }

    public static function selectAll(): array
    {
        $lista = [];
        $conn = new Connection();
        $sql = "SELECT id, nombres FROM carrera";
        $result = $conn->query($sql);
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $obj = self::rowToDto($row);
            $lista[] = $obj;
        }
        return $lista;
    }

    public static function selectById($id): ?Carrera
    {
        $conn = new Connection();
        $sql = "SELECT id, nombres FROM carrera WHERE id = :varId";
        $res = $conn->queryWithParams($sql, array(
            ":varId" => $id
        ));
        if ($res->rowCount() == 0) {
            return null;
        }
        if ($row = $res->fetch(PDO::FETCH_ASSOC)) {
            $obj = self::rowToDto($row);
        }
        return $obj;
    }

    private static function rowToDto($row): Carrera
    {
        $objCarrera = new Carrera();
        $objCarrera->setId($row["id"]);
        $objCarrera->setNombres($row["nombres"]);
        return $objCarrera;
    }

}