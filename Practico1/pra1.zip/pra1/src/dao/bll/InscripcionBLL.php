<?php

namespace App\dao\bll;

use App\dao\dal\Connection;
use App\dao\dto\Inscripcion;
use PDO;

class InscripcionBLL {

    public static function insert($estudiante_id, $materia_id): int {
        $conn = new Connection();
        $sql =
            "INSERT INTO inscripcion (estudiante_id, materia_id)
            VALUES (:varEstudiante_id, :varMateria_id)";

        $conn->queryWithParams($sql, array(
            ":varEstudiante_id" => $estudiante_id,
            ":varMateria_id" => $materia_id,
        ));
        return $conn->getLastInsertedId();
    }

    public static function update($estudiante, $materia, $id){
        $conn = new Connection();
        $sql =
            "UPDATE estudiantes
            SET estudiante_id = :varEstudiante_id, 
                materia_id = :varMateria_id
            WHERE 
                id = :varId";
        $conn->queryWithParams($sql, array(
            ":varEstudiante_id"       => $estudiante,
            ":varMateria_id"    => $materia,
            ":varId"            => $id,
        ));
    }

    public static function delete($id) {
        $conn = new Connection();

        $sql =
            "DELETE FROM inscripcion
            WHERE id = :varId";

        $conn->queryWithParams($sql, array(
            ":varId" => $id,
        ));
    }

    public static function selectAll(): array {
        $lista = [];
        $conn = new Connection();
        $sql =
            "SELECT id, estudiante_id, materia_id
            FROM inscripcion";

        $res = $conn->query($sql);
        while($row = $res->fetch(PDO::FETCH_ASSOC)){
            $obj     = self::rowToDto($row);
            $lista[] = $obj;
        }

        return $lista;
    }

    public static function selectAllById($id): array {
        $lista = [];
        $conn = new Connection();
        $sql =
            "SELECT id, estudiante_id, materia_id
            FROM inscripcion
            WHERE estudiante_id = :varId";

        $res = $conn->queryWithParams($sql, array(
            ":varId" => $id,
        ));
        while($row = $res->fetch(PDO::FETCH_ASSOC)){
            $obj     = self::rowToDto($row);
            $lista[] = $obj;
        }

        return $lista;
    }



    public static function selectById($id): ?Inscripcion {
        $conn = new Connection();
        $sql =
            "SELECT id, persona_id, materia_id
            FROM inscripcion
            WHERE id = :varId";

        $res = $conn->queryWithParams($sql, array(
            ":varId" => $id,
        ));

        if($res->rowCount() == 0){
            return null;
        }

        if($row = $res->fetch(PDO::FETCH_ASSOC)){
            $obj = self::rowToDto($row);
        }

        return $obj;
    }

    private static function rowToDto($row){
        $obj = new Inscripcion();
        $obj->setId($row["id"]);
        $obj->setEstudianteId($row["estudiante_id"]);
        $obj->setMateriaId($row["materia_id"]);
        return $obj;
    }
}