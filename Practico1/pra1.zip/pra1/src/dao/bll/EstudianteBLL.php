<?php

namespace App\dao\bll;

use App\dao\dal\Connection;
use App\dao\dto\Estudiante;
use PDO;

class EstudianteBLL {
    public static function insert($nombres, $apellidos, $usuario, $contrasena, $semestre, $carrera_id): int {
        $conn = new Connection();
        $sql =
            "INSERT INTO estudiantes (nombres, apellidos, usuario, contrasena, semestre, carrera_id) 
            VALUES(:varNombres, :varApellidos, :varUsuario, :varContrasena, :varSemestre, :varCarrera_id)";
        $conn->queryWithParams($sql, array(
            ":varNombres"       => $nombres,
            ":varApellidos"     => $apellidos,
            ":varUsuario"       => $usuario,
            ":varContrasena"    => $contrasena,
            ":varSemestre"      => $semestre,
            ":varCarrera_id"    => $carrera_id,
        ));
        return $conn->getLastInsertedId();
    }

    public static function update($nombres, $apellidos, $usuario, $contrasena, $semestre, $carrera_id, $id){
        $conn = new Connection();
        $sql =
            "UPDATE estudiantes
            SET nombres = :varNombres, 
                apellidos = :varApellidos,
                usuario = :varUsuario,
                contrasena = :varContrasena,
                semestre = :varSemestre,
                carrera_id = :varCarrera_id
            WHERE 
                id = :varId";
        $conn->queryWithParams($sql, array(
            ":varNombres"       => $nombres,
            ":varApellidos"     => $apellidos,
            ":varUsuario"       => $usuario,
            ":varContrasena"    => $contrasena,
            ":varSemestre"      => $semestre,
            ":varCarrera_id"    => $carrera_id,
            ":varId"            => $id,
        ));
    }

    public static function delete($id){
        $conn = new Connection();
        $sql =
            "DELETE FROM estudiantes
            where id = :varId";
        $conn->queryWithParams($sql, array(
            ":varId" => $id,
        ));
    }

    public static function validarEstudiante($usuario, $contrasena): ?Estudiante{
        $conn = new Connection();
        $sql =
            "SELECT id, nombres, apellidos, usuario, contrasena, semestre, carrera_id FROM estudiantes
            WHERE usuario = :varUsuario AND contrasena = :varContrasena";
        $res = $conn->queryWithParams($sql, array(
            ":varUsuario"       => $usuario,
            ":varContrasena"    => $contrasena,
        ));
        if($res->rowCount() == 0){
            return null;
        }

        $row = $res->fetch(PDO::FETCH_ASSOC);
        $obj = self::rowToDto($row);
        return $obj;
    }

    public static function selectAll(): array{
        $lista = [];
        $conn = new Connection();
        $sql =
            "SELECT id, nombres, apellidos, usuario, contrasena, semestre, carrera_id 
            FROM estudiantes";

        $res = $conn->query($sql);
        while($row = $res->fetch(PDO::FETCH_ASSOC)){
            // toma una fila y convierte a un objeto
            $obj = self::rowToDto($row);
            $lista[] = $obj;
        }
        return $lista;
    }

    public static function selectById($id): ?Estudiante{
        $conn = new Connection();
        $sql =
            "SELECT id, nombres, apellidos, usuario, contrasena, semestre, carrera_id 
            FROM estudiantes
            WHERE id = :varId";
        $res = $conn->queryWithParams($sql, array(
            ":varId" => $id,
        ));
        if($res->rowCount() == 0){
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        $obj = self::rowToDto($row);
        return $obj;
    }

    private static function rowToDto($row): Estudiante{
        $objEstudiante = new Estudiante();
        $objEstudiante->setId($row["id"]);
        $objEstudiante->setNombres($row["nombres"]);
        $objEstudiante->setApellidos($row["apellidos"]);
        $objEstudiante->setUsuario($row["usuario"]);
        $objEstudiante->setContrasena($row["contrasena"]);
        $objEstudiante->setSemestre($row["semestre"]);
        $objEstudiante->setCarreraId($row["carrera_id"]);

        return $objEstudiante;
    }
}