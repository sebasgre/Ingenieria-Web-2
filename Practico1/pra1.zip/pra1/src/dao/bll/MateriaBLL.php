<?php

namespace App\dao\bll;

use App\dao\dal\Connection;
use App\dao\dto\Materia;
use PDO;

class MateriaBLL {
    public static function insert($nombre, $semestre, $carrera_id): int {
        $conn = new Connection();
        $sql =
            "INSERT INTO materias (nombre, semestre, carrera_id)
            VALUES (:varNombre, :varSemestre, :varCarrera_id)";

        $conn->queryWithParams($sql, array(
            ":varNombre" => $nombre,
            ":varSemestre" => $semestre,
            ":varCarrera_id" => $carrera_id,
        ));
        return $conn->getLastInsertedId();
    }

    public static function update($nombre, $semestre, $carrera_id, $id){
        $conn = new Connection();
        $sql =
            "UPDATE materias
            SET nombre = :varNombre,
                semestre = :varSemestre,
                carrera_id = :varCarrera_id
            WHERE
                id = :varId";

        $conn->queryWithParams($sql, array(
            ":varNombre" => $nombre,
            ":varSemestre" => $semestre,
            ":varCarrera_id" => $carrera_id,
            ":varId" => $id,
        ));
    }

    public static function delete($id){
        $conn = new Connection();
        $sql =
            "DELETE FROM materias
            WHERE id = :varId";

        $conn->queryWithParams($sql, array(
            ":varId" => $id,
        ));
    }

    public static function selectAll(): array {
        $lista = [];
        $conn = new Connection();
        $sql =
            "SELECT id, nombre, semestre, carrera_id
            FROM materias";

        $res = $conn->query($sql);
        while($row = $res->fetch(PDO::FETCH_ASSOC)){
            // toma una fila y convierte a un objeto
            $obj = self::rowToDto($row);
            $lista[] = $obj;
        }

        return $lista;
    }

    public static function selectBySemestreAndCarrera($semestre, $carrera_id, $id): array {
        $lista = [];
        $conn = new Connection();
        $sql =
            "SELECT id, nombre, semestre, carrera_id
            FROM materias
            WHERE semestre = :varSemestre
            AND carrera_id = :varCarrera_id AND id NOT IN (select materia_id from inscripcion where estudiante_id = :varId)";

        $res = $conn->queryWithParams($sql, array(
            ":varSemestre" => $semestre,
            ":varCarrera_id" => $carrera_id,
            ":varId" => $id,
        ));
        while($row = $res->fetch(PDO::FETCH_ASSOC)){
            // toma una fila y convierte a un objeto
            $obj = self::rowToDto($row);
            $lista[] = $obj;
        }

        return $lista;
    }


    public static function selectById($id): ?Materia {
        $conn = new Connection();
        $sql =
            "SELECT id, nombre, semestre, carrera_id 
            FROM materias
            WHERE id = :varId";

        $res = $conn->queryWithParams($sql, array(
            ":varId" => $id,
        ));
        if($res->rowCount() == 0){
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        $obj = self::rowToDto($row);

        return $obj;
    }

    private static function rowToDto($row) : Materia{
        $objMateria = new Materia();
        $objMateria->setId($row["id"]);
        $objMateria->setNombre($row["nombre"]);
        $objMateria->setSemestre($row["semestre"]);
        $objMateria->setCarreraId($row["carrera_id"]);
        return $objMateria;
    }

//    public static function getAllCareers(): int
//    {
//        $total = 0;
//        $conn = new Connection();
//        $total = "SELECT count(*) from carrera";
//        return $total;
//    }
}