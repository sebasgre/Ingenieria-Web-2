<?php
require_once "config.php";
use App\dao\bll\InscripcionBLL;
use App\dao\bll\MateriaBLL;
use App\dao\bll\EstudianteBLL;
$id = null;
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}

if (isset($_REQUEST["id"])) {
    $id = $_REQUEST["id"];
}

$task = "select";
if(isset($_REQUEST["task"])){
    $task = $_REQUEST["task"];
}

switch ($task){
    case "INSERT":
        $estudiante = $_POST["id"];
        $materia = $_POST["idMateria"];
        InscripcionBLL::insert($estudiante, $materia);
        break;
    case "DELETE":
        $idMat = $_GET["idMat"];
        InscripcionBLL::delete($idMat);
        break;
}
$listaIncripciones = InscripcionBLL::selectAllById($id);

?>

<?php include_once "components/EstudianteHeader.php" ?>
<div class="container-fluid">
    <div class="card mt-3">
        <div class="card-body">
            <input type="hidden" name="id" value="<?php echo $id ?>">
            <h5 class="card-title">Lista de Inscripciones</h5>
            <a class="btn btn-primary"
               href="formInscripcion.php?id=<?php echo $id; ?>">Inscribir Materia</a>
            <table class="table">
                <thead>
                <tr>
                    <th>Estudiante</th>
                    <th>Materia</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($listaIncripciones as $objInscrito): ?>
                    <tr>
                        <?php
                        $materia = MateriaBLL::selectById($objInscrito->getMateriaId());
                        $estudiante = EstudianteBLL::selectById($objInscrito->getEstudianteId());
                        ?>
                        <td><?php echo $estudiante->getNombres()." ".$estudiante->getApellidos();?></td>
                        <td><?php echo $materia->getNombre();?></td>
                        <td><a onclick="return confirm('Está seguro que desea eliminar la carrera?')"
                               href="indexInscripcion.php?id=<?php echo $id;?>&idMat=<?php echo $objInscrito->getId();?>&task=DELETE"
                               class="btn btn-danger">Eliminar</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include_once "components/footer.php" ?>


