<?php
require_once "config.php";
use App\dao\bll\CarreraBLL;

$task = "select";
if(isset($_REQUEST["task"])){
    $task = $_REQUEST["task"];
}

switch ($task){
    case "INSERT":
        $nombre = $_POST["nombre"];
        CarreraBLL::insert($nombre);
        break;
    case "UPDATE":
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        CarreraBLL::update($nombre, $id);
        break;
    case "DELETE":
        $id = $_GET["id"];
        CarreraBLL::delete($id);
        break;
}
$listaCarreras = CarreraBLL::selectAll();
?>
<?php include_once "components/header.php" ?>
<div class="container-fluid">
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Lista de Carreras</h5>

            <table class="table">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($listaCarreras as $objCarrera): ?>
                    <tr>
                        <td><?php echo $objCarrera->getId();?></td>
                        <td><?php echo $objCarrera->getNombres();?></td>
                        <td><a class="btn btn-primary"
                               href="formCarrera.php?id=<?php echo $objCarrera->getId(); ?>">Editar</a></td>
                        <td><a onclick="return confirm('Está seguro que desea eliminar la carrera?')"
                               href="indexCarreras.php?id=<?php echo $objCarrera->getId();?>&task=DELETE"
                               class="btn btn-danger">Eliminar</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include_once "components/footer.php" ?>


