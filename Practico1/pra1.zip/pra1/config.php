<?php
include_once "vendor/autoload.php";
$username = "root";
$password = "root";
$hostname = "localhost";
$port = 3306;
$dbname = "practico1web2";