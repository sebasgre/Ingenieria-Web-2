<?php
require_once "config.php";

use App\dao\bll\EstudianteBLL;
use App\dao\bll\InscripcionBLL;
use App\dao\bll\MateriaBLL;

$task = "select";
if(isset($_REQUEST["task"])){
    $task = $_REQUEST["task"];
}

if ($task == "DELETE") {
    $id = $_GET["id"];
    InscripcionBLL::delete($id);
}
$listaInscritos = InscripcionBLL::selectAll();
?>
<?php include_once "components/header.php" ?>
<div class="container-fluid">
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Lista de Inscripciones</h5>

            <table class="table">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Estudiante</th>
                    <th>Materia</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($listaInscritos as $estudianteInscrito): ?>
                    <tr>
                        <?php $estudiante = EstudianteBLL::selectById($estudianteInscrito->getEstudianteId());
                                $materia = MateriaBLL::selectById($estudianteInscrito->getMateriaId());
                        ?>
                        <td><?php echo $estudianteInscrito->getId();?></td>
                        <td><?php echo $estudiante->getNombres()." ".$estudiante->getApellidos()?></td>
                        <td><?php echo $materia->getNombre();?></td>
                        <td><a onclick="return confirm('Está seguro que desea eliminar la inscripcion?')"
                               href="inscripciones.php?id=<?php echo $estudianteInscrito->getId();?>&task=DELETE"
                               class="btn btn-danger">Eliminar</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include_once "components/footer.php" ?>


