<?php
require_once "config.php";

use App\dao\bll\CarreraBLL;
use App\dao\bll\EstudianteBLL;

$task = "select";
if(isset($_REQUEST["task"])){
    $task = $_REQUEST["task"];
}

switch ($task){
    case "INSERT":
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $usuario = $_POST["usuario"];
        $pass = $_POST["contrasena"];
        $semestre = $_POST["semestre"];
        $carrera = $_POST["carrera"];
        EstudianteBLL::insert($nombre, $apellido, $usuario, $pass, $semestre, $carrera);
        break;
    case "UPDATE":
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $usuario = $_POST["usuario"];
        $pass = $_POST["contrasena"];
        $semestre = $_POST["semestre"];
        $carrera = $_POST["carrera"];
        EstudianteBLL::update($nombre, $apellido, $usuario, $pass, $semestre, $carrera, $id);
        break;
    case "DELETE":
        $id = $_GET["id"];
        EstudianteBLL::delete($id);
        break;
}
$listaEstudiantes = EstudianteBLL::selectAll();
?>
<?php include_once "components/header.php" ?>
<div class="container-fluid">
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Lista de Estudiantes</h5>

            <table class="table">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombres</th>
                    <th>Apellidos</th>
                    <th>USuario</th>
                    <th>Contraseña</th>
                    <th>Semestre</th>
                    <th>Carrera</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($listaEstudiantes as $objEstudiante): ?>
                    <tr>
                        <?php
                            $carrera = CarreraBLL::selectById($objEstudiante->getCarreraId());
                        ?>
                        <td><?php echo $objEstudiante->getId();?></td>
                        <td><?php echo $objEstudiante->getNombres();?></td>
                        <td><?php echo $objEstudiante->getApellidos();?></td>
                        <td><?php echo $objEstudiante->getUsuario();?></td>
                        <td><?php echo $objEstudiante->getContrasena();?></td>
                        <td><?php echo $objEstudiante->getSemestre();?></td>
                        <td><?php echo $carrera->getNombres()?></td>
                        <td><a class="btn btn-primary"
                               href="formEstudiante.php?id=<?php echo $objEstudiante->getId(); ?>">Editar</a></td>
                        <td><a onclick="return confirm('Está seguro que desea eliminar al estudiante?')"
                               href="indexEstudiantes.php?id=<?php echo $objEstudiante->getId();?>&task=DELETE"
                               class="btn btn-danger">Eliminar</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include_once "components/footer.php" ?>


