<?php


use App\controllers\ComunidadController;
use App\controllers\PublicacionController;
use App\controllers\UsuarioController;

$controller = "publicacion";
$action = "list";
if (isset($_REQUEST["controller"])) {
    $controller = $_REQUEST["controller"];
}
if (isset($_REQUEST["action"])) {
    $action = $_REQUEST["action"];
}
switch ($controller) {
    case "publicacion":
        switch ($action) {
            case "list":
                PublicacionController::index();
                break;
            case "create":
                PublicacionController::create();
                break;
            case "store":
                PublicacionController::store($_POST);
                break;
            case "edit":
                PublicacionController::edit($_GET["id"]);
                break;
            case "update":
                PublicacionController::update($_REQUEST["id"], $_POST);
                break;
            case "delete":
                PublicacionController::delete($_GET["id"]);
                break;
            case "listEspecifico":
                PublicacionController::indexEspecifico();
                break;
            case "like":
                PublicacionController::votar($_GET["id"]);
                break;
            case "dislike":
                PublicacionController::noVotar($_GET["id"]);
                break;
        }
        break;
    case "comunidad":
        switch ($action) {
            case "list":
                ComunidadController::index();
                break;
            case "create":
                ComunidadController::create();
                break;
            case "store":
                ComunidadController::store($_POST);
                break;
            case "edit":
                ComunidadController::edit($_GET["id"]);
                break;
            case "update":
                ComunidadController::update($_REQUEST["id"], $_POST);
                break;
            case "delete":
                ComunidadController::delete($_GET["id"]);
                break;
            case "listEspecifico":
                ComunidadController::indexEspecifico();
                break;
        }
        break;
    case "usuario":
        switch ($action) {
            case "validar":
                UsuarioController::validar();
                break;
            case "formLogin":
                UsuarioController::formLogin();
                break;
            case "formRegistro":
                UsuarioController::formRegistro();
                break;
            case "guardarDatos":
                UsuarioController::guardarDatos();
                break;
            case "logout":
                UsuarioController::logout();
                break;
        }
        break;
}
