<div class="alert alert-info">
    <?php if (isset($_SESSION["idUsuario"])): ?>
        <div>
            Usuario actualizado correctamente
            <?php echo $_SESSION["idUsuario"]; ?>
        </div>
    <?php endif; ?>
</div>
<?php
if (isset($_SESSION["error"])) :?>
    <div class="alert alert-danger">
        Hubo un error: <br> <?php echo $_SESSION["error"]; ?>
    </div>
    <?php unset($_SESSION["error"]); ?>
<?php endif; ?>
