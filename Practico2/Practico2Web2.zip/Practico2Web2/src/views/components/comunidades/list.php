<?php

use App\models\bll\UsuarioBLL;
use App\models\dto\Comunidad;

include_once "src/views/components/header.php";
/**
 * @var Comunidad[] $listaComunidades
 */
$usuario = null;
if (isset($_SESSION['usuario'])) {
    $correo = $_SESSION['usuario'];
    $usuario = UsuarioBLL::selectByCorreo($correo);
}
?>
<div class="container-fluid">
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Lista de Comunidades</h5>
            <?php include_once "src/views/components/messages.php"; ?>
            <table class="table">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Autor</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($listaComunidades as $objComunidad): ?>
                    <tr>
                        <td><?php echo $objComunidad->getId(); ?></td>
                        <td><?php echo $objComunidad->getNombre(); ?></td>
                        <td><?php echo $objComunidad->getCreadorForDisplay(); ?></td>
                        <?php if($usuario != null) : ?>
                        <td><a class="btn btn-primary"
                               href="index.php?controller=comunidad&action=edit&id=<?php echo $objComunidad->getId(); ?>">Editar</a>
                        </td>
                        <td><a onclick="return confirm('Está seguro que desea eliminar la comunidad?')"
                               href="index.php?controller=comunidad&action=delete&id=<?php echo $objComunidad->getId(); ?>"
                               class="btn btn-danger">Eliminar</a></td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include_once "src/views/components/footer.php" ?>
