<?php
require_once "config.php";


use App\models\bll\ComunidadBLL;
use App\models\bll\UsuarioBLL;
use App\models\dto\Comunidad;
use App\models\dto\Publicacion;
use App\models\dto\Usuario;


include_once "src/views/components/header.php";
/**
 * @var Comunidad $objComunidad
 * @var Usuario[] $listaUsuarios
 */
$id = 0;
$objComunidad = null;
if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $objComunidad = ComunidadBLL::selectById($id);
}
?>

<?php include_once "src/views/components/header.php" ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-4 mt-3 mb-3">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title">Formulario Comunidad</div>
                        <form method="post" action="index.php">
                            <input type="hidden"
                                   value="<?php echo ($objComunidad == null) ? 0 : $objComunidad->getId(); ?>"
                                   name="id">
                            <input type="hidden" name="action"
                                   value="<?php echo ($objComunidad == null) ? "store" : "update"; ?>">
                            <input type="hidden" name="controller" value="comunidad">
                            <div>
                                <label>Nombre:</label>
                                <input name="nombre" type="text" class="form-control"
                                       value="<?php echo $objComunidad != null ? $objComunidad->getNombre() : ""; ?>">
                            </div>
                            <div>
                                <?php $usuario = $_SESSION['usuario'];
                                $obj = UsuarioBLL::selectByCorreo($usuario)
                                ?>
                                <input name="creador_id" type="hidden" class="form-control"
                                       value="<?php echo $obj->getId() ?>"></input>
                            </div>
                            <div class="mt-2">
                                <button class="btn btn-primary" type="submit">Guardar</button>
                                <a href="index.php?controller=comunidad&action=list" class="btn btn-link">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include_once "src/views/components/footer.php" ?>