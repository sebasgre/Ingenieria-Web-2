<?php


use App\models\bll\UsuarioBLL;


$correo = $_REQUEST['correo'];
$contrasena = $_REQUEST['contrasena'];

$user = UsuarioBLL::validarUsuario($correo, $contrasena);

if ($user) {
    $_SESSION['usuario'] = $correo;
    header("Location: index.php");
} else {
    header("Location: index.php?controller=usuario&action=formLogin&msg=error");
}

