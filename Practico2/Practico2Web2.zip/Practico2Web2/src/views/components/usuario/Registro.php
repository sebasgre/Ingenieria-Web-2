<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap v5.1.3 CDNs -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- CSS File -->
    <link rel="stylesheet" href="css/style.css">
    <title>Registro</title>
</head>
<body>

<div class="login">
    <h1 class="text-center">Registro</h1>
    <p><?php
        if (isset($_GET['error'])) {
            echo "Datos incorrectos, ingrese nuevamente";
        }
        ?></p>
    <form class="needs-validation" action="index.php">
        <input type="hidden" name="controller" value="usuario">
        <input type="hidden" name="action" value="guardarDatos">
        <div class="form-group was-validated">
            <label class="form-label" for="nombre">Nombre</label>
            <input class="form-control" type="text" name="nombre" id="nombre" required>
            <div class="invalid-feedback">
                Por favor ingrese su nombre.
            </div>
        </div>
        <div class="form-group was-validated">
            <label class="form-label" for="apellido">Apellido</label>
            <input class="form-control" type="text" name="apellido" id="apellido" required>
            <div class="invalid-feedback">
                Por favor ingrese su apellido.
            </div>
        </div>
        <div class="form-group was-validated">
            <label class="form-label" for="email">Usuario</label>
            <input class="form-control" type="text" name="correo" id="email" required>
            <div class="invalid-feedback">
                Por favor ingrese su usuario.
            </div>
        </div>
        <div class="form-group was-validated">
            <label class="form-label" for="password">Contraseña</label>
            <input class="form-control" type="password" id="password" name="contrasena" required>
            <div class="invalid-feedback">
                Por favor ingrese su contraseña.
            </div>
        </div>
        <input class="btn btn-success w-100" type="submit" value="CREAR CUENTA">
    </form>
</div>
</body>
</html>
