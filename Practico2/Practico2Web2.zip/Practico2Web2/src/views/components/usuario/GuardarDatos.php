<?php



use App\models\bll\UsuarioBLL;

$nombre = $_REQUEST['nombre'];
$apellido = $_REQUEST['apellido'];
$correo = $_REQUEST['correo'];
$contrasena = $_REQUEST['contrasena'];

$bandera = "false";
$listaUsuario = UsuarioBLL::selectAll();
if ($nombre != "" && $apellido != "" && $correo != "" && $contrasena != "") {
    foreach ($listaUsuario as $objUsuario):
        if ($objUsuario->getCorreo() == $correo) {
            $bandera = "true";
            header("Location: index.php?controller=usuario&action=formRegistro&msg=error");
            break;
        } else {
            $bandera = "false";
        }
    endforeach;

    if ($bandera == "false") {
        UsuarioBLL::insert($nombre, $apellido, $correo, $contrasena);
        header("Location: index.php?controller=usuario&action=formLogin&msg=success");
    }
} else {
    header("Location: index.php?controller=usuario&action=formRegistro&msg=error");
}