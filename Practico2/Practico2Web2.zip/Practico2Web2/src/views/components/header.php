<?php

use App\models\bll\UsuarioBLL;

$usuario = null;
if (isset($_SESSION['usuario'])) {
    $correo = $_SESSION['usuario'];
    $usuario = UsuarioBLL::selectByCorreo($correo);
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script type="text/javascript" src="vendor/twbs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="vendor/twbs/bootstrap/dist/css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css"/>
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Reddit</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                <li class="nav-item dropdown">
                    <?php if ($usuario) : ?>
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                           aria-expanded="false">
                            Publicaciones
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="index.php?controller=publicacion&action=listEspecifico">Lista de
                                    Publicaciones</a></li>
                            <li><a class="dropdown-item" href="index.php?controller=publicacion&action=create">Crear
                                    publicacion</a></li>
                        </ul>
                    <?php else:
                        ?>
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                           aria-expanded="false">
                            Publicaciones
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="index.php?controller=publicacion&action=list">Lista de
                                    Publicaciones</a></li>
                        </ul>
                    <?php endif; ?>
                </li>
                <li class="nav-item dropdown">
                    <?php if ($usuario) : ?>
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                       aria-expanded="false">
                        Comunidades
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="index.php?controller=comunidad&action=listEspecifico">Lista de
                                Comunidades</a></li>
                        <li><a class="dropdown-item" href="index.php?controller=comunidad&action=create">Crear
                                comunidad</a></li>
                    </ul>
                    <?php else:
                        ?>
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                           aria-expanded="false">
                            Comunidades
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="index.php?controller=comunidad&action=list">Lista de
                                    Comunidades</a></li>
                        </ul>
                    <?php endif; ?>
                </li>
                <li class="nav-item">
                    <a class="nav-link"
                       href="#"><?php echo $usuario == null ? "" : $usuario->getCorreo() ?></a>
                </li>
                <li class="nav-item">
                    <?php if ($usuario) : ?>
                        <a class='nav-link' href='index.php?controller=usuario&action=logout'>Cerrar sesión</a>
                    <?php else: ?>
                        <a class='nav-link' href='index.php?controller=usuario&action=formLogin'>Iniciar sesión</a>
                    <?php endif; ?>
                </li>
            </ul>
        </div>
    </div>
</nav>
