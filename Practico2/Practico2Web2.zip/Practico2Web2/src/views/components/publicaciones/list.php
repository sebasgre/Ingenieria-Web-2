<?php

use App\models\bll\UsuarioBLL;
use App\models\dto\Publicacion;

include_once "src/views/components/header.php";
/**
 * @var Publicacion[] $listaPublicaciones
 */
$usuario = null;
if (isset($_SESSION['usuario'])) {
    $correo = $_SESSION['usuario'];
    $usuario = UsuarioBLL::selectByCorreo($correo);
}
?>
<div class="container-fluid">
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Lista de Publicaciones</h5>
            <?php include_once "src/views/components/messages.php"; ?>
            <table class="table">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Titulo</th>
                    <th>Descripcion</th>
                    <th>Votos</th>
                    <th>Comunidad</th>
                    <th>Autor</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($listaPublicaciones as $objPublicacion): ?>
                    <tr>
                        <td><?php echo $objPublicacion->getId(); ?></td>
                        <td><?php echo $objPublicacion->getTitulo(); ?></td>
                        <td><?php echo $objPublicacion->getDescripcion(); ?></td>
                        <td><?php echo $objPublicacion->getVotos(); ?></td>
                        <td><?php echo $objPublicacion->getComunidadForDisplay(); ?></td>
                        <td><?php echo $objPublicacion->getCreadorForDisplay(); ?></td>
                        <?php if ($usuario != null) : ?>
                            <td><a class="btn btn-success" href="index.php?controller=publicacion&action=like">Like</a></td>
                            <td><a class="btn btn-warning" href="index.php?controller=publicacion&action=dislike">No Like</a></td>
                            <td><a class="btn btn-primary"
                                   href="index.php?controller=publicacion&action=edit&id=<?php echo $objPublicacion->getId(); ?>">Editar</a>
                            </td>
                            <td><a onclick="return confirm('Está seguro que desea eliminar la comunidad?')"
                                   href="index.php?controller=publicacion&action=delete&id=<?php echo $objPublicacion->getId(); ?>"
                                   class="btn btn-danger">Eliminar</a></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include_once "src/views/components/footer.php" ?>
