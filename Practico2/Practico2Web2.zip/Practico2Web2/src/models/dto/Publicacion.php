<?php

namespace App\models\dto;

use App\models\bll\ComunidadBLL;
use App\models\bll\UsuarioBLL;

class Publicacion
{
    private $id;
    private $titulo;
    private $descripcion;
    private $votos;
    private $comunidad_id;
    private $creador_id;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getTitulo()
    {
        return $this->titulo;
    }

    /**
     * @param mixed $titulo
     */
    public function setTitulo($titulo)
    {
        $this->titulo = $titulo;
    }

    /**
     * @return mixed
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * @param mixed $descripcion
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;
    }

    /**
     * @return mixed
     */
    public function getVotos()
    {
        return $this->votos;
    }

    /**
     * @param mixed $votos
     */
    public function setVotos($votos)
    {
        $this->votos = $votos;
    }

    /**
     * @return mixed
     */
    public function getComunidadId()
    {
        return $this->comunidad_id;
    }

    /**
     * @param mixed $comunidad_id
     */
    public function setComunidadId($comunidad_id)
    {
        $this->comunidad_id = $comunidad_id;
    }

    /**
     * @return mixed
     */
    public function getCreadorId()
    {
        return $this->creador_id;
    }

    /**
     * @param mixed $creador_id
     */
    public function setCreadorId($creador_id)
    {
        $this->creador_id = $creador_id;
    }

    public function getCreadorForDisplay()
    {
        $usuario = UsuarioBLL::selectById($this->creador_id);
        return $usuario->getNombre() . " " . $usuario->getApellido();
    }

    public function getComunidadForDisplay()
    {
        $comunidad = ComunidadBLL::selectById($this->comunidad_id);
        return $comunidad->getNombre();
    }
}
