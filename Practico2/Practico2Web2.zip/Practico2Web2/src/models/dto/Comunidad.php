<?php

namespace App\models\dto;

use App\models\bll\ComunidadBLL;
use App\models\bll\UsuarioBLL;

class Comunidad
{
    private $id;
    private $nombre;
    private $creador_id;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    /**
     * @return mixed
     */
    public function getCreadorId()
    {
        return $this->creador_id;
    }

    /**
     * @param mixed $creador_id
     */
    public function setCreadorId($creador_id)
    {
        $this->creador_id = $creador_id;
    }

    public function  getCreadorForDisplay() {
        $creador = UsuarioBLL::selectById($this->creador_id);
        return $creador->getNombre() . " " . $creador->getApellido();
    }

}