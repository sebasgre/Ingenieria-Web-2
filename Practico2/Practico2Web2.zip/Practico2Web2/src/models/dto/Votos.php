<?php

namespace App\models\dto;

class Votos
{

}