<?php

namespace App\models\bll;

use App\models\dal\Connection;
use App\models\dto\Comunidad;
use PDO;
use PDOException;

class ComunidadBLL
{
    public static function insert($nombre, $creador_id): int
    {
        $conn = new Connection();
        $sql = "CALL sp_Comunidad_insert(:nombre, :creador_id)";
        $conn->queryWithParams($sql, array(
            ":nombre" => $nombre,
            ":creador_id" => $creador_id
        ));
        return $conn->getLastInsertedId();
    }

    public static function update($nombre, $creador_id, $id)
    {
        $conn = new Connection();
        $sql =
            "CALL sp_Comunidad_uptade(:nombre, :creador_id, :id)";
        $conn->queryWithParams($sql, array(
            ":nombre" => $nombre,
            ":creador_id" => $creador_id,
            ":id" => $id
        ));
    }

    public static function delete($id)
    {
        try {
            $conn = new Connection();
            $sql = "CALL sp_Comunidad_delete(:id)";
            $conn->queryWithParams($sql, array(
                ":id" => $id
            ));
        } catch (PDOException $e) {
            $_SESSION["error"] = e->getMessage();
        }
    }

    public static function selectAll()
    {
        $lista = [];
        $conn = new Connection();
        $sql =
            "CALL sp_Comunidad_selectAll()";
        $res = $conn->query($sql);
        while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
            $obj = self:: rowToDto($row);
            $lista[] = $obj;
        }
        return $lista;
    }

    public static function selectById($id): ?Comunidad
    {
        $conn = new Connection();
        $sql =
            "CALL sp_Comunidad_selectById(:id)";

        $res = $conn->queryWithParams($sql, array(
            "id" => $id
        ));
        if ($res->rowCount() == 0) {
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        $obj = self:: rowToDto($row);
        return $obj;
    }

    public static function selectByCreadorId($id): array
    {
        $data = UsuarioBLL::selectByCorreo($id);
        $conn = new Connection();
        $sql = "CALL sp_Comunidad_selectByCreadorId(:id)";
        $res = $conn->queryWithParams($sql, array(":id" => $data->getId()));
        while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
            $obj = self::rowToDto($row);
            $lista[] = $obj;
        }
        return $lista;
    }

    public static function rowToDto($row): Comunidad
    {
        $objComunidad = new Comunidad();
        $objComunidad->setId($row["id"]);
        $objComunidad->setNombre($row["nombre"]);
        $objComunidad->setCreadorId($row["creador_id"]);
        return $objComunidad;
    }
}