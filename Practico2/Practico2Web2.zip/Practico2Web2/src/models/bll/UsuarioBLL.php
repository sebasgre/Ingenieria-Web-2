<?php

namespace App\models\bll;

use App\models\dal\Connection;
use App\models\dto\Usuario;
use PDO;

class UsuarioBLL
{
    public static function insert($nombre, $apellido, $correo, $contrasena): int
    {
        $conn = new Connection();
        $sql = "CALL sp_Usuario_insert(:nombre, :apellido, :correo, :contrasena)";
        $conn->queryWithParams($sql, array(
            ":nombre" => $nombre,
            ":apellido" => $apellido,
            ":correo" => $correo,
            ":contrasena" => $contrasena
        ));
        return $conn->getLastInsertedId();
    }

    public static function validarUsuario($correo, $contrasena): ?Usuario
    {
        $conn = new Connection();
        $sql = "CALL sp_Usuario_validarUsuario(:correo, :contrasena)";
        $res = $conn->queryWithParams($sql, array(
            ":correo" => $correo,
            ":contrasena" => $contrasena
        ));
        if ($res->rowCount() == 0) {
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        $obj = self::rowToDto($row);
        return $obj;
    }

    public static function selectAll()
    {
        $lista = [];
        $conn = new Connection();
        $sql =
            "CALL sp_Usuario_selectAll()";
        $res = $conn->query($sql);
        while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
            $obj = self:: rowToDto($row);
            $lista[] = $obj;
        }
        return $lista;
    }

    public static function rowToDto($row)
    {
        $objUsuario = new Usuario();
        $objUsuario->setId($row["id"]);
        $objUsuario->setNombre($row["nombre"]);
        $objUsuario->setApellido($row["apellido"]);
        $objUsuario->setCorreo($row["correo"]);
        $objUsuario->setContrasena($row["contrasena"]);
        return $objUsuario;
    }

    public static function selectById($creador_id) :?Usuario
    {
        $conn = new Connection();
        $sql = "CALL sp_Usuario_selectById(:creador_id)";
        $res = $conn->queryWithParams($sql, array(
            ":creador_id" => $creador_id
        ));
        if ($res->rowCount() == 0) {
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        $obj = self::rowToDto($row);
        return $obj;
    }

    public static function selectByCorreo($correo) :?Usuario
    {
        $conn = new Connection();
        $sql = "CALL sp_Usuario_selectByCorreo(:correo)";
        $res = $conn->queryWithParams($sql, array(
            ":correo" => $correo
        ));
        if ($res->rowCount() == 0) {
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        $obj = self::rowToDto($row);
        return $obj;
    }
}