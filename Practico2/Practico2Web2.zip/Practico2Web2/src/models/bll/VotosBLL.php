<?php

namespace App\models\bll;

class VotosBLL
{

}