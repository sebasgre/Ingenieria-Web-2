<?php

namespace App\models\bll;

use App\models\dal\Connection;
use App\models\dto\Publicacion;
use PDO;

class PublicacionBLL
{
    public static function insert($titulo, $descripcion, $votos, $comunidad_id, $creador_id): int
    {
        $conn = new Connection();
        $sql = "CALL sp_Publicacion_insert(:titulo, :descripcion, :votos, :comunidad_id, :creador_id)";
        $conn->queryWithParams($sql, array(
            ":titulo" => $titulo,
            ":descripcion" => $descripcion,
            ":votos" => $votos,
            ":comunidad_id" => $comunidad_id,
            ":creador_id" => $creador_id
        ));
        return $conn->getLastInsertedId();
    }

    public static function delete($id)
    {
        $conn = new Connection();
        $sql =
            "CALL sp_Publicacion_delete(:id)";
        $conn->queryWithParams($sql, array(
            ":id" => $id
        ));
    }

    public static function update($titulo, $descripcion, $votos, $comunidad_id, $creador_id, $id)
    {
        $conn = new Connection();
        $sql =
            "CALL sp_Publicacion_update(:titulo, :descripcion, :votos, :comunidad_id, :creador_id, :id)";

        $conn->queryWithParams($sql, array(
            ":titulo" => $titulo,
            ":descripcion" => $descripcion,
            ":votos" => $votos,
            ":comunidad_id" => $comunidad_id,
            ":creador_id" => $creador_id,
            ":id" => $id
        ));
    }

    public static function selectAll(): array
    {
        $lista = [];
        $conn = new Connection();
        $sql = "CALL sp_Publicacion_selectAll()";
        $res = $conn->query($sql);
        while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
            $obj = self::rowToDto($row);
            $lista[] = $obj;
        }
        return $lista;
    }

    public static function selectById($id): ?Publicacion
    {
        $conn = new Connection();
        $sql = "CALL sp_Publicacion_selectById(:id)";
        $res = $conn->queryWithParams($sql, array(
            ":id" => $id
        ));
        if ($res->rowCount() == 0) {
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        $obj = self::rowToDto($row);
        return $obj;
    }

    public static function selectByCreadorId($id): array
    {
        $data = UsuarioBLL::selectByCorreo($id);
        $conn = new Connection();
        $sql = "CALL sp_Publicacion_selectByCreadorId(:id)";
        $res = $conn->queryWithParams($sql, array(":id" => $data->getId()));
        while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
            $obj = self::rowToDto($row);
            $lista[] = $obj;
        }
        return $lista;
    }

    public static function rowToDto($row): Publicacion
    {
        $objPublicacion = new Publicacion();
        $objPublicacion->setId($row["id"]);
        $objPublicacion->setTitulo($row["titulo"]);
        $objPublicacion->setDescripcion($row["descripcion"]);
        $objPublicacion->setVotos($row["votos"]);
        $objPublicacion->setComunidadId($row["comunidad_id"]);
        $objPublicacion->setCreadorId($row["creador_id"]);
        return $objPublicacion;
    }


}