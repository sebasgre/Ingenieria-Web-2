<?php

namespace App\controllers;

class UsuarioController
{
    static function validar()
    {
        require_once "src/views/components/usuario/ValidarFormulario.php";
    }

    static function formLogin() {
        require_once "src/views/components/usuario/Login.php";
    }

    public static function formRegistro()
    {
        require_once "src/views/components/usuario/Registro.php";
    }

    public static function guardarDatos()
    {
        require_once "src/views/components/usuario/GuardarDatos.php";
    }

    public static function logout()
    {
        require_once "src/views/components/usuario/Logout.php";
    }

}