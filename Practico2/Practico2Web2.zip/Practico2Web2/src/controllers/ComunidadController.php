<?php
namespace App\controllers;

use App\models\bll\ComunidadBLL;


class ComunidadController
{
    static function index()
    {
        $listaComunidades = ComunidadBLL::selectAll();
        require_once "src/views/components/comunidades/list.php";
    }

    static function create()
    {
        $objPersona = null;
        require_once "src/views/components/comunidades/form.php";
    }

    static function store($request)
    {
        $nombre = $request["nombre"];
        $creador_id = $request["creador_id"];
        ComunidadBLL::insert($nombre, $creador_id);
        ComunidadController::index();
    }

    static function edit($id)
    {
        $objComunidad = ComunidadBLL::selectById($id);
        require_once "src/views/components/comunidades/form.php";
    }

    static function update($id, $request)
    {
        $nombre = $request["nombre"];
        $creador_id = $request["creador_id"];
        ComunidadBLL::update($nombre, $creador_id, $id);
        ComunidadController::index();
    }

    static function delete($id)
    {
        ComunidadBLL::delete($id);
        ComunidadController::index();
    }

    public static function indexEspecifico()
    {
        $listaComunidades = ComunidadBLL::selectByCreadorId($_SESSION['usuario']);
        require_once "src/views/components/comunidades/list.php";
    }


}

?>
