<?php

namespace App\controllers;


use App\models\bll\PublicacionBLL;
use App\models\dto\Publicacion;

class PublicacionController
{
    static function index()
    {
        $listaPublicaciones = PublicacionBLL::selectAll();
        require_once "src/views/components/publicaciones/list.php";
    }

    static function indexEspecifico()
    {
        $listaPublicaciones = PublicacionBLL::selectByCreadorId($_SESSION['usuario']);
        require_once "src/views/components/publicaciones/list.php";
    }

    static function create()
    {
        $objPublicacion = null;
        $listaPublicaciones = PublicacionBLL::selectAll();
        require_once "src/views/components/publicaciones/form.php";
    }

    static function store($request)
    {
        $titulo = $request["titulo"];
        $descripcion = $request["descripcion"];
        $votos = 0;
        $comunidad_id = $request["comunidad_id"];
        $creador_id = $request["creador_id"];
        PublicacionBLL::insert($titulo, $descripcion, $votos, $comunidad_id, $creador_id);
        PublicacionController::index();
    }

    static function edit($id)
    {
        $objPublicacion = PublicacionBLL::selectById($id);
        $listaPublicaciones = PublicacionBLL::selectAll();
        require_once "src/views/components/publicaciones/form.php";
    }

    static function update($id, $request)
    {
        $titulo = $request["titulo"];
        $descripcion = $request["descripcion"];
        $votos = $request["votos"];
        $comunidad_id = $request["comunidad_id"];
        $creador_id = $request["creador_id"];
        PublicacionBLL::update($titulo, $descripcion, $votos, $comunidad_id, $creador_id, $id);
        PublicacionController::index();
    }

    static function delete($id)
    {
        PublicacionBLL::delete($id);
        PublicacionController::index();
    }

    static function votar($id)
    {
        $objPublicacion = PublicacionBLL::selectById($id);
        $votos = $objPublicacion->getVotos();
        $votos++;
        PublicacionBLL::update($objPublicacion->getTitulo(), $objPublicacion->getDescripcion(), $votos, $objPublicacion->getComunidadId(), $objPublicacion->getCreadorId(), $id);
        PublicacionController::index();
    }

    static function noVotar($id)
    {
        $objPublicacion = PublicacionBLL::selectById($id);
        $votos = $objPublicacion->getVotos();
        $votos--;
        PublicacionBLL::update($objPublicacion->getTitulo(), $objPublicacion->getDescripcion(), $votos, $objPublicacion->getComunidadId(), $objPublicacion->getCreadorId(), $id);
        PublicacionController::index();
    }

}

?>