<?php

namespace App\controllers;

use App\models\bll\ArtistaBLL;
use App\utils\ValidationUtils;

class ArtistaController
{
    static function index()
    {
        $listaArtistas = ArtistaBLL::selectAll();
        echo json_encode($listaArtistas);
    }

    static function store($body)
    {
        $request = json_decode($body);
        if ($request == null) {
            http_response_code(400);
            die("Error 404: Not Found");
        }
        if (!ValidationUtils::validarRequest($request, "nombre")) {
            return;
        }
        if (!ValidationUtils::validarRequest($request, "genero_id")) {
            return;
        }
        $nombre = $request->nombre;
        $genero_id = $request->genero_id;
        $id = ArtistaBLL::insert($nombre, $genero_id);
        $objArtista = ArtistaBLL::selectById($id);
        echo json_encode($objArtista);
    }

    static function updatePatch($id, $body)
    {
        $objArtista = ArtistaBLL::selectById($id);
        if ($objArtista == null) {
            http_response_code(404);
            die("Error 404: Not Found");
        }
        $request = json_decode($body);
        if ($request == null) {
            http_response_code(400);
            echo "request mal formado";
            return;
        }
        if (property_exists($request, "nombre")) {
            $objArtista->nombre = $request->nombre;
        }
        if (property_exists($request, "genero_id")) {
            $objArtista->genero_id = $request->genero_id;
        }
        ArtistaBLL::update($objArtista->nombre, $objArtista->genero_id, $objArtista->id);
        $objArtista = ArtistaBLL::selectById($id);
        echo json_encode($objArtista);
    }
    static function updatePut($id, $body)
    {
        $objArtista = ArtistaBLL::selectById($id);
        if ($objArtista == null) {
            http_response_code(400);
            die("Error 404: Not Found");
        }
        $request = json_decode($body);
        if ($request == null) {
            http_response_code(400);
            echo "request mal formado";
            return;
        }
        if (!ValidationUtils::validarRequest($request, "nombre")) {
            return;
        }
        $objArtista->nombre = $request->nombre;
        if (!ValidationUtils::validarRequest($request, "genero_id")) {
            return;
        }
        $objArtista->genero_id = $request->genero_id;
        ArtistaBLL::update($objArtista->nombre, $objArtista->genero_id, $id);
        $objArtista = ArtistaBLL::selectById($id);
        echo json_encode($objArtista);
    }
    static function delete($id)
    {
        $objArtista = ArtistaBLL::selectById($id);
        if ($objArtista == null) {
            http_response_code(404);
            die("Error 404: Not Found");
        }
        ArtistaBLL::delete($id);
        echo json_encode($objArtista);
    }

    static function detail($id)
    {
        $objArtista = ArtistaBLL::selectById($id);
        if ($objArtista == null) {
            http_response_code(404);
            die("Error 404: Not Found");
        }
        echo json_encode($objArtista);
    }

    public static function photo($id, array $files)
    {
        $objArtista = ArtistaBLL::selectById($id);
        if ($objArtista == null) {
            http_response_code(404);
            die("Error 404: Not Found");
        }
        // move file to img folder
        $file    = $files["artista"];
        $tmp     = $file["tmp_name"];
        $ext     = pathinfo($file["name"], PATHINFO_EXTENSION);
        $newName = $id.".".$ext;
        $newPath = "artista/".$newName;
        move_uploaded_file($tmp, $newPath);
        echo "{\"res\":\"ok\"}";
    }

     static function artistaGeneros($id)
    {
        $listaGeneros = ArtistaBLL::selectByGenero($id);
        echo json_encode($listaGeneros);
    }
}