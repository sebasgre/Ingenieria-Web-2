<?php

namespace App\controllers;

use App\models\bll\AlbumBLL;
use App\models\bll\GeneroBLL;
use App\utils\ValidationUtils;

class AlbumController
{
    static function index()
    {
        $listaAlbums = AlbumBLL::selectAll();
        echo json_encode($listaAlbums);
    }

    static function store($body)
    {
        $request = json_decode($body);
        if ($request == null) {
            http_response_code(400);
            die("Error 404: Not Found");
        }
        if (!ValidationUtils::validarRequest($request, "nombre")) {
            return;
        }
        $nombre = $request->nombre;
        if (!ValidationUtils::validarRequest($request, "artista_id")) {
            return;
        }
        $artista_id = $request->artista_id;
        $id = AlbumBLL::insert($nombre, $artista_id);
        $objAlbum = AlbumBLL::selectById($id);
        echo json_encode($objAlbum);
    }

    static function updatePatch($id, $body)
    {
        $objAlbum = AlbumBLL::selectById($id);
        if ($objAlbum == null) {
            http_response_code(404);
            die("Error 404: Not Found");
        }
        $request = json_decode($body);
        if ($request == null) {
            http_response_code(400);
            echo "request mal formado";
            return;
        }
        if (property_exists($request, "nombre")) {
            $objAlbum->nombre = $request->nombre;
        }
        if (property_exists($request, "artista_id")) {
            $objAlbum->artista_id = $request->artista_id;
        }
        AlbumBLL::update($objAlbum->nombre, $objAlbum->artista_id, $id);
        $objAlbum = AlbumBLL::selectById($id);
        echo json_encode($objAlbum);
    }

    static function updatePut($id, $body)
    {
        $objAlbum = AlbumBLL::selectById($id);
        if ($objAlbum == null) {
            http_response_code(404);
            die("Error 404: Not Found");
        }
        $request = json_decode($body);
        if ($request == null) {
            http_response_code(400);
            die("Error 400: Bad Request");
        }
        if (!ValidationUtils::validarRequest($request, "nombre")) {
            return;
        }
        $objAlbum->nombre = $request->nombre;
        if (!ValidationUtils::validarRequest($request, "artista_id")) {
            return;
        }
        $objAlbum->artista_id = $request->artista_id;
        AlbumBLL::update($objAlbum->nombre, $objAlbum->artista_id, $id);
        $objAlbum = AlbumBLL::selectById($id);
        echo json_encode($objAlbum);
    }

    static function delete($id)
    {
        $objAlbum = AlbumBLL::selectById($id);
        if ($objAlbum == null) {
            http_response_code(404);
            die("Error 404: Not Found");
        }
        AlbumBLL::delete($id);
        echo json_encode($objAlbum);
    }

    static function detail($id)
    {
        $objAlbum = AlbumBLL::selectById($id);
        if ($objAlbum == null) {
            http_response_code(404);
            die("Error 404: Not Found");
        }
        echo json_encode($objAlbum);
    }

    public static function photo($id, array $files)
    {
        $objAlbum = AlbumBLL::selectById($id);
        if ($objAlbum == null) {
            http_response_code(404);
            die("Error 404: Not Found");
        }
        // move file to img folder
        $file = $files["albums"];
        $tmp = $file["tmp_name"];
        $ext = pathinfo($file["name"], PATHINFO_EXTENSION);
        $newName = $id . "." . $ext;
        $newPath = "albums/" . $newName;
        move_uploaded_file($tmp, $newPath);
        echo "{\"res\":\"ok\"}";
    }

    public static function albumArtista($id)
    {
        $listaAlbums = AlbumBLL::selectByArtista($id);
        echo json_encode($listaAlbums);
    }


}