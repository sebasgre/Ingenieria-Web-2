<?php

namespace App\models\bll;

use App\models\dal\Connection;
use App\models\dto\Artista;
use PDO;
use PDOException;

class ArtistaBLL
{
    public static function insert($nombre, $genero_id): int
    {
        try {
            $conn = new Connection();
            $sql = "CALL sp_Artista_insert(:varNombre, :varGenero_id);";

            $res = $conn->queryWithParams($sql, array(
                ":varNombre" => $nombre,
                ":varGenero_id" => $genero_id
            ));
            $row = $res->fetch(PDO::FETCH_ASSOC);

            return $row["lastId"];
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
        return 0;
    }

    public static function delete($id)
    {
        try {
            $conn = new Connection();
            $sql = "CALL sp_Artista_delete(:varId)";

            $conn->queryWithParams($sql, array(
                ":varId" => $id,
            ));
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
    }

    public static function update($nombre, $genero_id, $id)
    {
        try {
            $conn = new Connection();
            $sql =
                "CALL sp_Artista_update(
                                    :varNombre, 
                                    :varGenero_id, 
                                    :varId
                                    );";

            $conn->queryWithParams($sql, array(
                ":varNombre" => $nombre,
                ":varGenero_id" => $genero_id,
                ":varId" => $id
            ));
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
    }

    public static function selectAll() :array
    {
        try {
            $lista = [];
            $conn = new Connection();
            $sql =
                "CALL sp_Artista_selectAll()";

            $res = $conn->query($sql);
            while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
                $obj = self::rowToDto($row);
                $lista[] = $obj;
            }

            return $lista;
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }

        return [];
    }

    public static function selectByGenero($genero_id) :array
    {
        try {
            $lista = [];
            $conn = new Connection();
            $sql =
                "CALL sp_Artista_selectByGenero(:varGenero_id)";

            $res = $conn->queryWithParams($sql, array(
                ":varGenero_id" => $genero_id
            ));
            while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
                $obj = self::rowToDto($row);
                $lista[] = $obj;
            }

            return $lista;
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }

        return [];
    }

    public static function selectById($id): ?Artista
    {
        $conn = new Connection();
        $sql =
            "CALL sp_Artista_selectById(:varId)";

        $res = $conn->queryWithParams($sql, array(
            ":varId" => $id
        ));
        if ($res->rowCount() == 0) {
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        return self::rowToDto($row);
    }

//    public static function selectByIdGenero($id)
//    {
//        try {
//            $lista = [];
//            $conn = new Connection();
//            $sql =
//                "CALL sp_Artista_selectByIdGenero(:varId)";
//
//            $res = $conn->queryWithParams($sql, array(
//                ":varId" => $id
//            ));
//            while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
//                $obj = self::rowToDto($row);
//                $lista[] = $obj;
//            }
//
//            return $lista;
//        } catch (PDOException $e) {
//            $_SESSION["error"] = $e->getMessage();
//        }
//        return [];
//    }

    private static function rowToDto($row): Artista
    {
        $objArtista = new Artista();
        $objArtista->setId($row["id"]);
        $objArtista->setNombre($row["nombre"]);
        $objArtista->setGeneroId($row["genero_id"]);
//        $objArtista->genero = GeneroBLL::selectByIdArtista($objArtista->getGeneroId());
        if(isset($row["generoId"])){
            $objArtista->setGenero($row["generoNombre"], $row["generoId"]);
        }
        return $objArtista;
    }


}