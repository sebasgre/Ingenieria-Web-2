<?php

namespace App\models\bll;

use App\models\dal\Connection;
use App\models\dto\Cancion;
use PDO;
use PDOException;

class CancionBLL
{
    public static function insert($nombre, $album_id): int
    {
        try {
            $conn = new Connection();
            $sql =
                "CALL sp_Cancion_insert(
                                    :varNombre, 
                                    :varAlbumId
                                    );";

            $res = $conn->queryWithParams($sql, array(
                ":varNombre" => $nombre,
                ":varAlbumId" => $album_id
            ));
            $row = $res->fetch(PDO::FETCH_ASSOC);

            return $row["lastId"];
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
        return 0;
    }

    public static function delete($id)
    {
        try {
            $conn = new Connection();
            $sql =
                "CALL sp_Cancion_delete(:varId)";

            $conn->queryWithParams($sql, array(
                ":varId" => $id,
            ));
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
    }

    public static function update($nombre, $album_id, $id)
    {
        try {
            $conn = new Connection();
            $sql =
                "CALL sp_Cancion_update(
                                    :varNombre, 
                                    :varAlbum_id, 
                                    :varId
                                    );";

            $conn->queryWithParams($sql, array(
                ":varNombre" => $nombre,
                ":varAlbum_id" => $album_id,
                ":varId" => $id
            ));
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
    }

    public static function selectAll(): array
    {
        try {
            $lista = [];
            $conn = new Connection();
            $sql =
                "CALL sp_Cancion_selectAll()";

            $res = $conn->query($sql);
            while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
                $obj = self::rowToDto($row);
                $lista[] = $obj;
            }

            return $lista;
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }

        return [];
    }

    public static function selectById($id): ?Cancion
    {
        $conn = new Connection();
        $sql =
            "CALL sp_Cancion_selectById(:varId)";

        $res = $conn->queryWithParams($sql, array(
            ":varId" => $id
        ));
        if ($res->rowCount() == 0) {
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        return self::rowToDto($row);
    }

    private static function rowToDto($row): Cancion
    {
        $objCancion = new Cancion();
        $objCancion->setId($row["id"]);
        $objCancion->setNombre($row["nombre"]);
        $objCancion->setAlbumId($row["album_id"]);
        if (isset($row["albumId"])) {
            $objCancion->setAlbum($row["albumNombre"], $row["albumArtistaId"], $row["albumId"]);
        }
        return $objCancion;
    }

    public static function selectCancionesAlbumPorArtista($id)
    {
        try {
            $lista = [];
            $conn = new Connection();
            $sql =
                "CALL sp_Album_selectByCancion(:varId);";

            $res = $conn->queryWithParams($sql, array(
                ":varId" => $id
            ));
            while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
                $obj = self::rowToDto($row);
                $lista[] = $obj;
            }

            return $lista;
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
        return [];
    }
}