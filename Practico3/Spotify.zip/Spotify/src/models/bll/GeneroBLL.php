<?php

namespace App\models\bll;

use App\models\dal\Connection;
use App\models\dto\Genero;
use PDO;
use PDOException;

class GeneroBLL
{
    public static function insert($nombre): int
    {
        try {
            $conn = new Connection();
            $sql = "CALL sp_Genero_insert(:varNombre);";

            $res = $conn->queryWithParams($sql, array(
                ":varNombre" => $nombre
            ));
            $row = $res->fetch(PDO::FETCH_ASSOC);

            return $row["lastId"];
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
        return 0;
    }

    public static function delete($id)
    {
        try {
            $conn = new Connection();
            $sql = "CALL sp_Genero_delete(:varId)";

            $conn->queryWithParams($sql, array(
                ":varId" => $id,
            ));
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
    }

    public static function update($nombre, $id)
    {
        try {
            $conn = new Connection();
            $sql =
                "CALL sp_Genero_update(
                                    :varNombre, 
                                    :varId
                                    );";

            $conn->queryWithParams($sql, array(
                ":varNombre" => $nombre,
                ":varId" => $id
            ));
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }
    }

    public static function selectAll()
    {
        try {
            $lista = [];
            $conn = new Connection();
            $sql =
                "CALL sp_Genero_selectAll()";

            $res = $conn->query($sql);
            while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
                $obj = self::rowToDto($row);
                $lista[] = $obj;
            }

            return $lista;
        } catch (PDOException $e) {
            $_SESSION["error"] = $e->getMessage();
        }

        return [];
    }

    public static function selectById($id)
    {
        $conn = new Connection();
        $sql =
            "CALL sp_Genero_selectById(:varId)";

        $res = $conn->queryWithParams($sql, array(
            ":varId" => $id
        ));
        if ($res->rowCount() == 0) {
            return null;
        }
        $row = $res->fetch(PDO::FETCH_ASSOC);
        return self::rowToDto($row);
    }
//    public static function selectByIdArtista($genero_id)
//    {
//        try {
//            $lista = [];
//            $conn = new Connection();
//            $sql =
//                "CALL sp_Genero_selectByIdArtista(:varGenero_id)";
//
//            $res = $conn->queryWithParams($sql, array(
//                ":varGenero_id" => $genero_id
//            ));
//            while ($row = $res->fetch(PDO::FETCH_ASSOC)) {
//                $obj = self::rowToDto($row);
//                $lista[] = $obj;
//            }
//
//            return $lista;
//        } catch (PDOException $e) {
//            $_SESSION["error"] = $e->getMessage();
//        }
//
//        return [];
//    }

    private static function rowToDto($row)
    {
        $objGenero = new Genero();
        $objGenero->setId($row["id"]);
        $objGenero->setNombre($row["nombre"]);
        return $objGenero;
    }


}