<?php

namespace App\models\dto;

use App\models\bll\GeneroBLL;
use stdClass;

class Artista
{
    public $id;
    public $nombre;
    public $genero_id;
    /**
     * @var stdClass
     */
    public $genero;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    /**
     * @return mixed
     */
    public function getGeneroId()
    {
        return $this->genero_id;
    }

    /**
     * @param mixed $genero_id
     */
    public function setGeneroId($genero_id)
    {
        $this->genero_id = $genero_id;
    }


    public function setGenero($generoNombre, $generoId)
    {
        $this->genero = new StdClass();
        $this->genero->nombre = $generoNombre;
        $this->genero->id = $generoId;
    }


}