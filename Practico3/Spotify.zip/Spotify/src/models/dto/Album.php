<?php

namespace App\models\dto;

use stdClass;

class Album
{
    public $id;
    public $nombre;
    public $artista_id;
    public $album;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    /**
     * @return mixed
     */
    public function getArtistaId()
    {
        return $this->artista_id;
    }

    /**
     * @param mixed $artista_id
     */
    public function setArtistaId($artista_id)
    {
        $this->artista_id = $artista_id;
    }

    public function setArtista($artistaNombre, $artistaGeneroId, $artistaId)
    {
        $this->album = new stdClass();
        $this->album->nombre = $artistaNombre;
        $this->album->genero_id = $artistaGeneroId;
        $this->album->id = $artistaId;
    }


}