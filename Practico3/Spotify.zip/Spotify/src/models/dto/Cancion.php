<?php
namespace App\models\dto;

use stdClass;

class Cancion
{
    public $id;
    public $nombre;
    public $album_id;
    public $cancion;
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    /**
     * @return mixed
     */
    public function getAlbumId()
    {
        return $this->album_id;
    }

    /**
     * @param mixed $album_id
     */
    public function setAlbumId($album_id)
    {
        $this->album_id = $album_id;
    }

    public function setAlbum($albumNombre, $albumArtistaId, $albumId)
    {
        $this->cancion = new stdClass();
        $this->cancion->nombre = $albumNombre;
        $this->cancion->artista_id = $albumArtistaId;
        $this->cancion->id = $albumId;
    }


}